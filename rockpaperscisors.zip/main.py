import random
rock = '''
    _______
---'   ____)
      (_____)
      (_____)
      (____)
---.__(___)
'''

paper = '''
    _______
---'   ____)____
          ______)
          _______)
         _______)
---.__________)
'''

scissors = '''
    _______
---'   ____)____
          ______)
       __________)
      (____)
---.__(___)
'''

#Write your code below this line 👇
r = [rock, paper, scissors]
c = int(input("What do you choose? Type 0 for Rock, 1 for Paper or 2 for Scissors.\n"))
if c < 0 or c > 2:
  print("You inserted an invalide number.")
else:
  print(r[c])
  p = random.randint(0,2)
  print(f"Computer's choice: \n {r[p]}")
  if c < p:
    print("You lose!")
  elif c > p:
    print("You win!")
  elif c == p:
    print("It's a draw!")
  else:
    print("You lose! ")